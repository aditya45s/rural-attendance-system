import { EduTraceApp } from '@/components/EduTraceApp';

const Index = () => {
  return <EduTraceApp />;
};

export default Index;
